spiri_description
=================

Simulation of Spiri in Gazebo
